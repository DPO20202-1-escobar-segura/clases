import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class Proyecto {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		String Titulo,Descripcion;
		int tiempo;
		
		System.out.println(" Ingrese titulo ");

		Titulo = teclado.nextLine();
		
		System.out.println(" Ingrese descripcion ");

		Descripcion = teclado.nextLine();
		
		LocalDate FechaInicial = LocalDate.now();
		
		System.out.println(" Ingrese cuanto tardara la actividad en dias");
		tiempo = teclado.nextInt();
		LocalDate FechaFinal = LocalDate.now().plusDays(tiempo);
		
		System.out.println("ACTIVIDAD CREADA!");
		System.out.println("Titulo:"+ Titulo + "Descripcion:"+ Descripcion + "fecha inicial:"+ FechaInicial + "Fecha Final:"+ FechaFinal);
		
		String Proyecto = ("Titulo:"+ Titulo + "Descripcion:"+ Descripcion + "fecha inicial:"+ FechaInicial + "Fecha Final:"+ FechaFinal);
		String LeerProyecto="";
		
		try {
			FileWriter fichero = new FileWriter ("Proyectos.txt");
					fichero.write(Proyecto);
					fichero.close();
		}catch (Exception ex) { ex.printStackTrace(); }


		try {
			FileReader lector= new FileReader ("Proyectos.txt");
			BufferedReader BR = new BufferedReader(lector);
			LeerProyecto=BR.readLine();
		}catch (Exception ex) { ex.printStackTrace(); }

	}
	
}