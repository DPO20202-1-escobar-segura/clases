import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.LocalTime;


public class actividad {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		String Titulo,Descripcion,Tipo;
		int tiempo;

		System.out.println(" Ingrese titulo ");

		Titulo = teclado.nextLine();

		System.out.println(" Ingrese descripcion ");

		Descripcion = teclado.nextLine();
		
		System.out.println(" Ingrese tipo ");

		Tipo = teclado.nextLine();
		
		LocalDate Fecha = LocalDate.now();
		
		LocalTime HoraInicio = LocalTime.now();
		
		System.out.println(" Ingrese cuanto tardara la actividad");
		tiempo = teclado.nextInt();
		LocalTime HoraFinal = LocalTime.now().plusHours(tiempo);	
		
		
		System.out.println("ACTIVIDAD CREADA POR:"+ participante + "Titulo:"+ Titulo + "descripcion:" + Descripcion + "tipo:"+ Tipo + "fecha:" + Fecha + "hora inicial:" + HoraInicio + "Hora final:" + HoraFinal);
		
		String actividad = ("Titulo:"+ Titulo + "descripcion:" + Descripcion + "tipo:"+ Tipo + "fecha:" + Fecha + "hora inicial:" + HoraInicio + "Hora final:" + HoraFinal);
		String LeerActividad="";

		try {
			FileWriter fichero = new FileWriter ("actividades.txt");
					fichero.write(actividad);
					fichero.close();
		}catch (Exception ex) { ex.printStackTrace(); }


		try {
			FileReader lector= new FileReader ("actividades.txt");
			BufferedReader BR = new BufferedReader(lector);
			LeerActividad=BR.readLine();
		}catch (Exception ex1) { ex1.printStackTrace(); }


		 }
		
	}
		


