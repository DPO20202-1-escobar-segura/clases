import java.math.BigInteger;

public class stopwatch {

    public static void main(String[] args) {

        Stopwatch1 stopwatch1 = new Stopwatch1();
        stopwatch1.start();
        Fibonacci(45);
        stopwatch1.stop();


        System.out.println("tiempo en millisegundos: "
                + stopwatch1.getElapsedMilliseconds());

        System.out.println("tiempo en segundos: "
                + stopwatch1.getElapsedSeconds());

        System.out.println("tiempo en minutos: "
                + stopwatch1.getElapsedMinutes());

        System.out.println("tiempo en horas: "
                + stopwatch1.getElapsedHours());

    }

    private static BigInteger Fibonacci(int n) {
        if (n < 2)
            return BigInteger.ONE;
        else
            return Fibonacci(n - 1).add(Fibonacci(n - 2)); 
    }
}

